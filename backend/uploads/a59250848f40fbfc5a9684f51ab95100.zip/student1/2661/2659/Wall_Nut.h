#pragma once
#include "Planta.h"

using namespace Plantele;


class Wall_Nut:public Planta
{
public:
	Wall_Nut();
	~Wall_Nut();
};

