#pragma once
#include "Planta.h"
#include "Interactiune.h"
#include "Coordonate.h"
#include <io.h>
#include <fcntl.h>

using namespace Plantele;

class Floarea_Soarelui: public Planta
{
public:
	Floarea_Soarelui();
	~Floarea_Soarelui();

};

