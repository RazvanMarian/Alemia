#include "IZombie.h"
