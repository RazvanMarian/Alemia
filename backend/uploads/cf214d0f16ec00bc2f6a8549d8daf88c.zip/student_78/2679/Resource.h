#pragma once
class Resource
{
public:
	Resource() {};
	~Resource() {};
};

