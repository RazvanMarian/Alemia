#pragma once
#include "Planta.h"

using namespace Plantele;

class IceBean:public Planta
{

public:
	IceBean();
	~IceBean();
};

