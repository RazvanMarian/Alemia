#pragma once

#include "Entity.h"

class Inter_plante:public Entity
{
public:

	virtual ~Inter_plante();

};

