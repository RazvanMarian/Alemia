#pragma once
#include "Plant.h"
class Chery_Bomb :public Plant
{
public:
	Chery_Bomb();

	virtual~Chery_Bomb();
};

