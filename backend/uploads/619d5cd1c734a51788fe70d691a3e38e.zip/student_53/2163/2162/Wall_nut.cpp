#include "Wall_nut.h"



Wall_nut::Wall_nut():Plant('W', 10000000,{10,22},50)
{
}


Wall_nut::~Wall_nut()
{
}
