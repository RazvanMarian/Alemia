#include "Snow_pea.h"



Snow_pea::Snow_pea():Plant('F', 1000000,{10,27},175)
{
}


Snow_pea::~Snow_pea()
{
}
