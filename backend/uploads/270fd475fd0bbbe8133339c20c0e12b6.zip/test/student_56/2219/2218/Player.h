#pragma once
class Player
{
public:
	void start_game();
	void start_intro();
	Player();
	~Player();
};

