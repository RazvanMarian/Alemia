#pragma once
class IZombie
{
public:
	virtual void print() = 0;
	virtual void move() = 0;
};

