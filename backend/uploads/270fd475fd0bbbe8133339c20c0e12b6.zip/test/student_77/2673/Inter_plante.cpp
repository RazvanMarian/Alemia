#include "Inter_plante.h"

Inter_plante::~Inter_plante()
{
}
