In caz ca aplicatia nu merge: se intra in Project->Properties->Advanced is se seteaza Chatacter Set pe Use Multi-Byte Character Set

Mentionez ca nu sunt implementate clase de exceptii, log sau user-login