#pragma once
#include "Bulet.h"
class NormalB :
	public Bulet
{
public:
	NormalB(SHORT, SHORT, int);
	void set();
};

