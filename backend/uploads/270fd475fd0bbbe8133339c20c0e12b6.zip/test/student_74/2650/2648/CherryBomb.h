#pragma once
#include "Plant.h"
class CherryBomb :
	public Plant
{
public:
	CherryBomb(SHORT, SHORT);
	void interaction();
	void set();
};

