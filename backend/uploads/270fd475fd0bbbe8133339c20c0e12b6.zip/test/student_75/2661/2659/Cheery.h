#pragma once
#include "Planta.h"

using namespace Plantele;

class Cheery: public Planta
{
public:
	Cheery();
	~Cheery();
};

