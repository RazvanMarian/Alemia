#include "Sunflower.h"



Sunflower::Sunflower():Plant('S', 1000000,{10,17},50)
{
}


Sunflower::~Sunflower()
{
}
