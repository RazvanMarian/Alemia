#include "WallNut.h"
int WallNut::SpawnTime = 2000;
