#pragma once
#include "Zombie.h"
class NormalZ :
	public Zombie
{
public:
	NormalZ(SHORT, SHORT);
	void interaction();
	void set();
};

