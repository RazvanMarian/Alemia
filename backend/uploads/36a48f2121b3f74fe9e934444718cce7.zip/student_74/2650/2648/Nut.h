#pragma once
#include "Plant.h"
class Nut :
	public Plant
{
public:
	Nut(SHORT, SHORT);
	void interaction() {}
	void set();
};

