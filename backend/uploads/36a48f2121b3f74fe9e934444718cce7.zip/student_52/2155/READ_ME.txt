

Jocul contine un ecran de pornire cu niste animatii,dupa care urmeaza fereastra de log in.
In cazul in care utilizatorul a introdus un nume de cont nou sau s a logat cu un cont existent
deja jocul porneste.
Datele de logare sunt salvate intr un fisier din cadrul programului.
In joc se pot adauga entitati Pea,Sunflower care trebuie sa rezista in fata valurilor de
Zombie/BucketheadZombie.
Jocul se termina cand toti zombii sunt exterminati sau cand un zombie a trecut de apararea
jucatorului.