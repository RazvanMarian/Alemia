#include "Zombie_BucketHead.h"



Zombie_BucketHead::Zombie_BucketHead()
{
}

Zombie_BucketHead::Zombie_BucketHead(int health, COORD A, int damage, int rezistenta, int viteza, string name,int time):Zombie(health,A,damage,rezistenta,viteza,name,time)
{
}


Zombie_BucketHead::~Zombie_BucketHead()
{
}
